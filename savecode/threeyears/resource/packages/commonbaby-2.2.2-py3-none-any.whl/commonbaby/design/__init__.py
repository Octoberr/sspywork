"""design tools"""

# -*- coding:utf-8 -*-

from .singleton import SingletonDecorator, SingletonInstance
