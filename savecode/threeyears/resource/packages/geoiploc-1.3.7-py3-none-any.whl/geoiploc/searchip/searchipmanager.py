"""
这里管理所有的ip查询和反查

进行一些细节操作，可能涉及到数据的归并，去重等
每个插件都更新自己的东西
create by judy 2020/04/10
"""
from .dbip import DBIP


class SearchIPMannager(object):

    def __init__(self):
        pass

    @classmethod
    def _mmdb_get_ip_loc(cls, ip: str) -> dict:
        """
        只获取mmdb的ip地址
        """
        dbip = DBIP()
        res = dbip.get_ip_geoinfo(ip)
        return res

    @classmethod
    def get_ip_location(cls, ip: str) -> dict:
        """
        管理使用ip获取归属地的总入口，可以用于信息比较
        信息汇总，数据去重
        """
        res = cls._mmdb_get_ip_loc(ip)
        return res
