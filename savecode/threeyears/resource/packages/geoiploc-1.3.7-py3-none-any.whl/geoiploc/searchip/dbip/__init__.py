from .dbip import DBIP

import threading
dbip = DBIP()
threading.Thread(target=dbip.do_async_download_dbip, daemon=False).start()
