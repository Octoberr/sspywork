"""
DBIP的一些查询和反查工作
create by judy 2020/04/10
这里要修改下如果没有下载成功，那么就先用旧的
"""
import time
import datetime
import gzip
import json
import math
import shutil
import threading
import traceback
from pathlib import Path
from apscheduler.schedulers.background import BackgroundScheduler

import maxminddb
import pytz
import requests
# from commonbaby.countrycodes import ALL_COUNTRIES, CountryCode
from commonbaby.mslog import MsLogger, MsLogManager
from partdownload import PartDFile


class DBIP(object):
    # 这个加锁的原因是因为当多个ip scouter需要去下载一个东西的时候不去下载那么多次
    __init_ip_locker = threading.Lock()
    _db_date: str = None
    # 这个要做到更新的话应该记录当前的月份
    _is_dbip_downloaded: bool = False

    def __init__(self):
        # 这个文件夹拿来放压缩包
        # 全放到资源文件夹下去： idown/resource/dbip/
        self.tmppath: Path = Path('./_ip_location_dbs/tmpfile')
        self.tmppath.mkdir(exist_ok=True, parents=True)
        # 这个文件夹拿来放mmdb
        self.dbpath: Path = Path('./_ip_location_dbs/dbfile')
        self.dbpath.mkdir(exist_ok=True, parents=True)

        # 理论上当前db最新的名字
        self.date_now = datetime.datetime.now(pytz.timezone('Asia/Shanghai'))
        self.date = self.date_now.strftime('%Y-%m')
        self.__judge_localdb_status()
        self.dbname = self.dbpath / f'{self.date}.mmdb'

        self._logger: MsLogger = MsLogManager.get_logger("DBIP-mmdb")

        # 初始化的时候下载dbip库
        self.__async_download_dbip()

    def __judge_localdb_status(self):
        """
        判断下是否需要去跟新数据库
        """
        # 这里判断下是否需要去下载数据库
        # 这里可以不用加锁，可以同时支持多个线程同时
        # 第一次下载
        if DBIP._db_date is None:
            DBIP._is_dbip_downloaded = False
        else:
            year = self.date_now.year
            month = self.date_now.month
            name_list = DBIP._db_date.split('-')
            db_year = int(name_list[0])
            db_month = int(name_list[1])
            # 新的一月需要重新去下载
            if db_year != year or db_month != month:
                DBIP._is_dbip_downloaded = False

    def __init__download_dbip(self):
        """
        多线程检测是否下载了dbip，这样比以前下载的时候去下载dbip要快一点
        modify by judy 2020/03/31
        :return:
        """
        if DBIP._is_dbip_downloaded:
            return
        # 下载数据库的状态
        res = False
        try:
            with DBIP.__init_ip_locker:
                if DBIP._is_dbip_downloaded:
                    return
                # 这里包括检查版本和下载IP库
                res = self.__check_db_version()
        except:
            self._logger.error(f"Init download dbip error, err:{traceback.format_exc()}")
        finally:
            if res:
                # 将下载完成的状态给上
                DBIP._is_dbip_downloaded = True
                # 每月数据库下载成功后记录下当前的名字
                DBIP._db_date = self.date
            else:
                # 将下载完成的状态给上
                DBIP._is_dbip_downloaded = False

    def __check_db_version(self):
        """
        检测现存的db与当前年月是否对应
        无论如何最后都会在db文件夹存在一个文件
        :return:
        """
        # 默认需要去下载数据库
        need_download = True
        exist_dbname = None
        # 下载数据库的状态
        download_status = False

        year = self.date_now.year
        month = self.date_now.month
        file_list = [i for i in self.dbpath.iterdir()]
        file_count = len(file_list)

        if file_count > 0:
            for file in file_list:
                exist_dbname: str = file.name
                name_list = exist_dbname[:exist_dbname.index('.')].split('-')
                db_year = int(name_list[0])
                db_month = int(name_list[1])
                if db_year == year and db_month == month:
                    # 符合要求当月的都能使用
                    need_download = False
                    break
        # 如果需要去下载新的数据库，那么就去下载
        if need_download:
            download_status = self.__download_db()
        # 检测下载状态，下载成功直接返回，如果没有下载成功那么就使用原有的db，原有的db也没有那么就报错
        if download_status:
            return True
        else:
            if exist_dbname is not None:
                olddbname = self.dbpath / exist_dbname
                # 重命名，这个月就不去更新了
                olddbname.rename(self.dbname)
                return True
            else:
                self._logger.error('There is a problem with the network connection, no available mmdb can be use')
                return False

    def __download_db(self):
        """
        在dbip网站下载mmdb
        :return:
        """
        self._logger.info("Start init download mmdb")
        res = False
        gzname = self.tmppath / f'{self.date}.mmdb.gz'
        dbname = self.dbname
        try:
            # 下载到tmp文件夹
            # url = f'https://download.db-ip.com/free/dbip-city-lite-{self.date}.mmdb.gz'
            dbip_upgrade_url = 'https://db-ip.com/account/7fcd7421494b209426e44b8729aa1606c973e49a/db/ip-to-location-isp/'
            response = requests.get(dbip_upgrade_url, timeout=(5, 5))
            d_res = json.loads(response.text)
            url = d_res.get('mmdb', {}).get('url')

            f = PartDFile(url,
                          savedir=self.tmppath.absolute().as_posix(),
                          filename=f'{self.date}.mmdb.gz',
                          conncount=10)
            f.download_async(
                lambda a: self._logger.info("mmdb download completed"))

            while not f.download_complete:
                try:
                    self._logger.info(
                        f'Downloading dbip mmdb: {f.download_total_size_realtime//(1024*1024)} Mb/ {f._totalsize//(1024*1024)} Mb    avg: {f.speed_average_str}'
                    )
                    time.sleep(2)
                except Exception as ex:
                    self._logger.error(f"Wait for downloading err: {ex.args}")


            # count = 0
            # with requests.get(url, stream=True, timeout=(5, 5)) as r:
            #     r.raise_for_status()
            #     total_length = math.ceil(
            #         int(r.headers.get('content-length')) / (1024 * 1024))
            #     with gzname.open('wb') as f:
            #         # with progressbar.ProgressBar(max_value=total_length, widgets=widgets) as bar:
            #         for chunk in r.iter_content(chunk_size=1024 * 1024):
            #             count += 1
            #             # bar.update(count)
            #             self._logger.info(
            #                 f'Downloading mmdb: {count} Mb/ {total_length} Mb')
            #             if chunk:  # filter out keep-alive new chunks
            #                 f.write(chunk)
            self._logger.info("Please waite unzip mmdb")
            # 解压到db文件夹
            with gzip.open(gzname.as_posix(), 'rb') as f_in:
                with dbname.open('wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
            self._logger.info('Unzip mmdb success')
            res = True
        except:
            self._logger.info(
                f"Download dbip error, err:{traceback.format_exc()}")
            res = False
            # 下载失败需要重新解压
            if dbname.exists():
                dbname.unlink()
        finally:
            # 删除tmppath里面的file
            if gzname.exists():
                gzname.unlink()
        return res

    def get_ip_geoinfo(self, ip: str) -> dict:
        """
        根据ip去查询所在的地址
        :param ip:
        :return:
        """
        res = {}
        self.__manage_used_db()
        # 检查下初始化是否下载了dbip库，如果没有下载，那么表示网络可能出现了问题
        if not DBIP._is_dbip_downloaded:
            self._logger.error("DBdatabase is not downloaded, check the network")
            return res

        try:
            # 1、先检测下东西在不在
            # 这样当前dbname就一定会有
            # with DbipMmdb.__scouter_ip_locker:
            # 一次只能有一个玩意在这检测版本，虽然慢但是多线程没办法
            # self.__check_db_version()
            reader = maxminddb.open_database(self.dbname.as_posix())
            res = reader.get(ip)
            if res is None:
                return res
            reader.close()
        except Exception as error:
            self._logger.error("Get geoinfo error:\nip={}\nerror:{}".format(ip, error))
        finally:
            return res

    def do_async_download_dbip(self):
        import time
        # 经测试，在docker容器内报错时区不符，随便指定一个时区就可以解决
        # 此处统一指定为上海
        schedule = BackgroundScheduler(timezone="Asia/Shanghai")
        schedule.add_job(self.__async_download_dbip, 'cron', month="*", day="1", hour='3', id='async_download_db')
        schedule.start()
        while True:
            time.sleep(5)

    def __async_download_dbip(self):
        """
        多线程检测是否下载了dbip，这样比以前下载的时候去下载dbip要快一点
        modify by judy 2020/03/31
        :return:
        """
        if DBIP._is_dbip_downloaded:
            return
        # 下载数据库的状态
        res = False
        try:
            with DBIP.__init_ip_locker:
                if DBIP._is_dbip_downloaded:
                    return
                # 这里包括文件个数检测和下载数据
                self.__delete_old_db()
                res = self.__check_db_update()
        except:
            self._logger.error(f"Init download dbip error, err:{traceback.format_exc()}")
        finally:
            if res:
                # 将下载完成的状态给上
                DBIP._is_dbip_downloaded = True
                # 每月数据库下载成功后记录下当前的名字
                DBIP._db_date = self.date
            else:
                # 将下载完成的状态给上
                DBIP._is_dbip_downloaded = False

    def __delete_old_db(self):
        """
        扫描db文件夹，判断当前db的版本
        """
        file_list = [i for i in self.dbpath.iterdir()]
        month = self.date_now.month
        year = self.date_now.year
        if len(file_list) == 0:
            return

        for file in file_list:
            name_list = file.name.split(".")[0].split("-")
            name_year = int(name_list[0])
            name_month = int(name_list[1])
            if name_year == year:
                if name_month + 1 < month:
                    file.unlink()
            else:
                if name_month != 12:
                    file.unlink()

    def __check_db_update(self):
        date = self.date_now.strftime('%Y-%m')
        file_list = [i for i in self.dbpath.iterdir() if i.name.split(".")[0] == date]
        file_count = len(file_list)
        if file_count == 0:
            return self.__download_db()
        else:
            return False

    def __manage_used_db(self):
        data = self.date_now.strftime('%Y-%m')
        file_list = [i for i in self.dbpath.iterdir() if i.name.split(".")[0] == data]
        file_count = len(file_list)
        if file_count == 0:
            year = self.date_now.year
            month = self.date_now.month - 1
            if month < 10:
                date = f'{year}-0{month}'
            else:
                date = f'{year}-{month}'
            self.dbname = self.dbpath / f'{date}.mmdb'
        else:
            DBIP._is_dbip_downloaded = True


if __name__ == '__main__':
    # test db download
    db_ip = DBIP()

    # test get info
    ip = "61.135.185.32"
    info = db_ip.get_ip_geoinfo(ip=ip)
    print(info)
