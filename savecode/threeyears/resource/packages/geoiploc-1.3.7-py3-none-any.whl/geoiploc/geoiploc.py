"""
1、IP归属地插叙
2、根据ip的归属地来查询ip段
目前来说实现的只有dbip
这里是总的入口 create by judy 2020/04/10
"""
from .searchip.searchipmanager import SearchIPMannager
from .searchloc.searchlocmanager import SearchLocManager


class GeoIPLoc(object):

    @classmethod
    def get_ip_location(cls, ip: str) -> dict:
        """
        根据ip去查归属地，外部调用方法汇总
        """
        res = SearchIPMannager.get_ip_location(ip)
        return res

    @classmethod
    def get_country_code_ipranges(cls, country_code):
        """
        根据国家二字码获取ip段方法汇总
        """
        res = SearchLocManager.get_country_code_ipranges(country_code)
        return res

    @classmethod
    def get_location_ipranges(cls, country_code, province=None, city=None, geoid=None):
        """
        根据地址去查ip段
        查询的是某个具体的地址
        """
        res = SearchLocManager.get_region_ipranges(country_code, province, city, geoid)
        return res
