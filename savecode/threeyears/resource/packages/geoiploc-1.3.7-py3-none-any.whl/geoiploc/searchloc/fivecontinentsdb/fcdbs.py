"""
全世界有5大ip地址提供商，所以可以根据地区二字码查到该地区被分配的ip数
modify by judy 2020/04/14
"""
import math
import os
import threading
import time
from pathlib import Path

from partdownload import PartDFile


class IPLocation(object):
    """the class provide ip to location searching"""

    # the key value pairs of download links and static db files
    db_files: {} = {
        'arin.db':
        # 'ftp://ftp.arin.net/pub/stats/arin/delegated-arin-extended-latest',
            'https://ftp.arin.net/pub/stats/arin/delegated-arin-extended-latest',
        'ripe.db':
        # 'ftp://ftp.ripe.net/ripe/stats/delegated-ripencc-latest',
            'https://ftp.ripe.net/ripe/stats/delegated-ripencc-latest',
        'afrinic.db':
        # 'ftp://ftp.afrinic.net/pub/stats/afrinic/delegated-afrinic-latest',
            'https://ftp.afrinic.net/pub/stats/afrinic/delegated-afrinic-latest',
        'lacnic.db':
        # 'ftp://ftp.lacnic.net/pub/stats/lacnic/delegated-lacnic-latest',
            'https://ftp.lacnic.net/pub/stats/lacnic/delegated-lacnic-latest',
        'apnic.db':
        # 'ftp://ftp.apnic.net/public/apnic/stats/apnic/delegated-apnic-latest'
            'https://ftp.apnic.net/public/apnic/stats/apnic/delegated-apnic-latest'
    }

    refresh_time: {} = {
        'arin.db': 0,
        'ripe.db': 0,
        'afrinic.db': 0,
        'lacnic.db': 0,
        'apnic.db': 0
    }

    # the cache of [countrycode,ipranges]
    cache_ips = {}
    # cache operation locker
    cache_ips_locker = threading.Lock()

    # the directory used for saving the static db files
    db_file_dir = os.path.join(os.getcwd(), "_ip_location_dbs")
    # default is total seconds of a day
    update_interval = 24 * 60 * 60
    # locker for refresh local db
    refresh_db_locker = threading.Lock()

    # if is the first time call this class
    is_first_call: bool = True
    is_first_call_locker = threading.Lock()

    # the log func
    _log = lambda m: print(m)

    def __init__(self):
        pass

    @classmethod
    def set_logger(cls, f):
        """set the logger while error occours.
        f: the delegate which recieves a message str.
        something like: def log(msg): print(msg)"""
        cls._log = f

    @classmethod
    def set_update_db_interval(cls, day: float):
        """set refresh db interval by day. set '-1' to prevent updating"""
        if day is None or not type(day) in (int, float):
            return
        if day <= 0:
            day = -1
            cls.update_interval = -1
        elif day > 0:
            cls.update_interval = day * 24 * 60 * 60

    @classmethod
    def get_ip_range_by_country_code(cls, countrycode: str) -> []:
        """search all ip ranges by country code.
        countrycode: the Country Code. like: US, CN. etc."""
        res: [] = []

        cls.__delete_none_db_file()

        if cls.is_first_call:
            cls.__get_last_db_refresh_time()

        cls.__check_local_db_files()

        try:
            # search
            res = cls.__get_ip_range_mask(countrycode)
        except Exception as ex:
            if not cls._log is None and callable(cls._log):
                cls._log("Search ip range of '%s' error: %s" %
                         (countrycode, ex))
            else:
                raise ex
            res = []

        return res

    @classmethod
    def __get_ip_range_mask(cls, countrycode: str) -> []:
        """search ip range in mask form, like '1.1.1.1/24', from local dbs"""
        res: [] = []

        with cls.cache_ips_locker:
            if cls.cache_ips.__contains__(countrycode):
                res = cls.cache_ips[countrycode]
                return res

        for fiName in cls.db_files:
            path = os.path.join(cls.db_file_dir, fiName)
            if not os.path.exists(path) or not os.path.isfile(path):
                continue
            tmp = cls.__search_from_one_db(path, countrycode)
            for t in tmp:
                if not res.__contains__(t):
                    res.append(t)

        with cls.cache_ips_locker:
            if not cls.cache_ips.__contains__(countrycode):
                cls.cache_ips[countrycode] = res

        return res

    @classmethod
    def __search_from_one_db(cls,
                             dbfi: str,
                             countrycode: str,
                             itype: str = "ipv4") -> []:
        """search ip ranges from given db file.
        dbfi: one of the local db files.
        countrycode: target country code.
        itype: ip type, all/ipv4,ipv6"""
        res: [] = []
        fs = None
        try:
            fs = open(dbfi, 'r')
            for line in fs:
                if line[0] == '#':
                    continue
                items = line.split('|')
                if items[1] != countrycode:
                    continue

                if itype != 'all':
                    if itype == 'ipv4' and items[2] != 'ipv4':
                        continue
                    elif itype == 'ipv6' and items[2] != 'ipv6':
                        continue
                    # if itype is a wrong value:
                    elif items[2] != 'ipv4':
                        continue
                elif items[2] == 'asn':
                    continue

                # parse ip range
                ip: str = None
                if items[2] == 'ipv4':
                    ip = '%s/%d' % (items[3],
                                    32 - int(math.log(int(items[4]), 2)))
                elif items[2] == 'ipv6':
                    ip = '%s/%s' % (items[3], items[4])

                # add to result
                if not ip is None and not res.__contains__(ip):
                    res.append(ip)

            return res
        finally:
            if not fs is None:
                fs.close()

    @classmethod
    def __get_last_db_refresh_time(cls):
        """get the time of last time the db file refreshed."""
        with cls.is_first_call_locker:
            try:
                if not cls.is_first_call:
                    return

                for fi in cls.db_files:
                    path = os.path.join(cls.db_file_dir, fi)
                    if not os.path.exists(path) or not os.path.isfile(path):
                        continue
                    t = os.path.getmtime(path)
                    if t > cls.refresh_time[fi]:
                        cls.refresh_time[fi] = t

            except Exception as ex:
                if not cls._log is None and callable(cls._log):
                    cls._log(
                        "get local db file modify time error, will update local db file: %s"
                        % ex)
                else:
                    raise ex
            finally:
                cls.is_first_call = False

    @classmethod
    def __check_local_db_files(cls):
        """check if local db files are exist. if not, will download them."""
        with cls.refresh_db_locker:
            try:
                for fiName, t in cls.refresh_time.items():
                    try:
                        path = os.path.join(cls.db_file_dir, fiName)
                        if os.path.exists(path) and (
                                cls.update_interval < 0
                                or time.time() - t <= cls.update_interval):
                            continue

                        if not cls._log is None and callable(cls._log):
                            cls._log("Updating ip-location db: %s" % fiName)

                        # if not os.path.exists(path) or not os.path.isfile(path):
                        cls.__download_db_file(cls.db_files[fiName], path)
                        cls.refresh_time[fiName] = time.time()
                        cls.cache_ips.clear()
                    except Exception as ex:
                        if not cls._log is None and callable(cls._log):
                            cls._log(
                                "Update local ip-location databse error: %s" %
                                ex)
                        else:
                            raise ex

            except Exception as ex:
                if not cls._log is None and callable(cls._log):
                    cls._log("Update local ip-location databse error: %s" % ex)
                else:
                    raise ex

    @classmethod
    def __download_db_file(cls, url: str, savePath: str):
        """download the specified db file and save to specified path"""
        if url is None or url == '':
            return
        try:
            # create save directory
            saveDir = os.path.dirname(savePath)
            if not os.path.exists(saveDir):
                os.makedirs(saveDir)
            elif not os.path.isdir(saveDir):
                os.makedirs(saveDir)

            # make tmp filepath
            tmpfi = savePath + '.tmp'

            # req = urllib.request.Request(url)
            # response = urllib.request.urlopen(req)
            pt = Path(tmpfi)
            pdf = PartDFile(url,
                            savedir=pt.parent.__str__(),
                            filename=pt.name,
                            conncount=5,
                            partsize=1048576,
                            cachesize=1048576,
                            buffersize=102400)
            pdf.download()

            if os.path.isfile(savePath):
                os.remove(savePath)
            os.rename(tmpfi, savePath)

        except Exception as ex:
            if not cls._log is None and callable(cls._log):
                cls._log("download ip database error: \nurl:%s\nexception:%s" %
                         (url, ex.args))

    @classmethod
    def __delete_none_db_file(cls):
        """"""
        if not os.path.exists(cls.db_file_dir):
            return

        for fi in os.listdir(cls.db_file_dir):
            try:
                path = os.path.join(cls.db_file_dir, fi)
                if not os.path.isfile(path):
                    continue
                if not cls.refresh_time.__contains__(fi):
                    os.remove(path)
            except Exception as ex:
                if not cls._log is None and callable(cls._log):
                    cls._log("delete none db file error: %s" % ex)

# def _log(msg: str):
#     print(msg)
#
#
# def _print_help():
#     print("""
#     Input a 2-digit countrycode like 'US' or 'CN'...
#
#     Options:
#      -o output to a file
#
#     command example:
#     python3 iplocation.py US -o ./ip_range.txt
#     """)


# if __name__ == '__main__':
#     try:
#         if len(sys.argv) < 2:
#             _print_help()
#             sys.exit()
#         print("Initialing...")
#         IPLocation.set_logger(_log)
#         IPLocation.set_update_db_interval(1)
#         ips = IPLocation.get_ip_range_by_country_code("IN")
#         print("Initialed")
#
#         code = None
#         if len(sys.argv) >= 2:
#             code = sys.argv[1]
#         if code is None or code == '':
#             _print_help()
#             sys.exit()
#
#         param = None
#         outfile = None
#         if len(sys.argv) >= 3:
#             param = sys.argv[2]
#             if not param is None and param == '-o' and len(sys.argv) >= 4:
#                 outfile = sys.argv[3]
#             else:
#                 _print_help()
#                 sys.exit()
#
#         ips = IPLocation.get_ip_range_by_country_code(code)
#
#         if not outfile is None or outfile == '':
#             with open(outfile, mode='w', encoding='utf-8') as fs:
#                 for ip in ips:
#                     fs.write(ip.strip().rstrip() + '\n')
#         else:
#             for ip in ips:
#                 print(ip)
#
#     except Exception as ex:
#         print(ex.args)
