"""
扫描城市ip段的管理器
modify bu judy 2020/04/14
这里进行一些细节汇总工作
"""
from .fivecontinentsdb import IPLocation
from .dbip import DBIPMMDB


class SearchLocManager(object):

    def __init__(self):
        pass

    @classmethod
    def get_country_code_ipranges(cls, country_code):
        """
        使用国家二字码
        获取五大洲统计的国家ip段
        类似于：CN, HK, IN, ID
        """
        ipranges = IPLocation.get_ip_range_by_country_code(country_code)
        return ipranges

    @classmethod
    def get_region_ipranges(cls, country_code, province=None, city=None, geoid=None):
        """
        使用地区代码来获取ip段，但是这个地区需要和前端合作
        """
        dm = DBIPMMDB()
        ipranges = dm.find_geo_ip_ranges(country_code, province, city, geoid)
        return ipranges

