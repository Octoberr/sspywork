from .dbipmmdb import DBIPMMDB

import threading
db_ip_mmdb = DBIPMMDB()
threading.Thread(target=db_ip_mmdb.do_async_download_csv, daemon=False).start()