"""
这里有两个功能
这里需要下载csv，然后需要保存csv到本地数据库
"""
import time
import datetime
import gzip
import json
import math
import shutil
import sqlite3
import threading
import traceback
from pathlib import Path
from apscheduler.schedulers.background import BackgroundScheduler

import pandas
import pytz
import requests
from commonbaby.mslog import MsLogger, MsLogManager
from partdownload import PartDFile

from .iso2cc import country_code


class SeRes(object):
    def __init__(self, conn=None, res=None):
        self.conn = conn
        self.res = res

    def sedone(self):
        """
        任务完成，需要手动调用下
        结束那个连接，sqlite的连接很奇怪的，如果每次查询的sql是相同的那么就只在
        内存中实例化一个， 但是如果sql不同，那么就会新建立连接，虽然sqlite能建立很多连接
        但是也是有上限的，所以还是需要手动关闭下连接
        """
        if self.conn is not None:
            self.conn.close()


class DBIPMMDB(object):
    # 这个加锁的原因是因为当多个ip scouter需要去下载一个东西的时候不去下载那么多次
    __init_ip_locker = threading.Lock()
    # true if we have downloaded dbip
    _csv_date: str = None
    _is_dbip_downloaded: bool = False

    def __init__(self):
        # 这个文件夹拿来放压缩包
        # 全放到资源文件夹下去： idown/resource/dbip/
        self.tmppath: Path = Path('./_ip_location_dbs/tmpfile')
        self.tmppath.mkdir(exist_ok=True, parents=True)
        # 这个文件夹拿来放csv文件
        self.csvpath: Path = Path('./_ip_location_dbs/csvfile')
        self.csvpath.mkdir(exist_ok=True, parents=True)
        # 这个文件夹放sqlite数据库
        self.sqlite_path: Path = Path('./_ip_location_dbs/dbipsqlite')
        self.sqlite_path.mkdir(exist_ok=True, parents=True)

        # 当前db的名字
        self.date_now = datetime.datetime.now(pytz.timezone('Asia/Shanghai'))
        self.date = self.date_now.strftime('%Y-%m')
        self.__judge_localcsv_status()
        self.csvname = self.csvpath / f'{self.date}.csv'

        self._logger: MsLogger = MsLogManager.get_logger("DBIP-csv")

        # 将csv的数据保存到sqlite
        self.sqlite_name = self.sqlite_path / f'{self.date}.sqlite'

        # 初始化的时候下载dbip库，和sqlite库
        self.__async_download_csv()

    def __judge_localcsv_status(self):
        """
        判断下是否需要去跟新数据库
        """
        # 这里判断下是否需要去下载数据库
        # 这里可以不用加锁，可以同时支持多个线程同时
        # 第一次下载
        if DBIPMMDB._csv_date is None:
            DBIPMMDB._is_dbip_downloaded = False
        else:
            year = self.date_now.year
            month = self.date_now.month
            name_list = DBIPMMDB._csv_date.split('-')
            db_year = int(name_list[0])
            db_month = int(name_list[1])
            # 新的一月需要重新去下载
            if db_year != year or db_month != month:
                DBIPMMDB._is_dbip_downloaded = False

    def __init__download_csv(self):
        """
        多线程检测是否下载了dbip，这样比以前下载的时候去下载dbip要快一点
        modify by judy 2020/03/31
        :return:
        """
        if DBIPMMDB._is_dbip_downloaded:
            return
        # 下载数据库的状态
        res = False
        try:
            with DBIPMMDB.__init_ip_locker:
                if DBIPMMDB._is_dbip_downloaded:
                    return
                # 这里包括检查版本和下载csv文件
                csvres = self.__check_db_version()
                # 下载失败就不去init sqlite了初始化也没用
                if not csvres:
                    return res
                # 下载完成csv文件后，初始化下sqlite数据库
                sqliteres = self.__init__sqlite_db()
                if csvres and sqliteres:
                    res = True
        except:
            self._logger.error(
                f"Init download dbip error, err:{traceback.format_exc()}")
        finally:
            if res:
                # 将下载完成的状态给上
                DBIPMMDB._is_dbip_downloaded = True
                DBIPMMDB._csv_date = self.date
            else:
                # 将下载完成的状态给上
                DBIPMMDB._is_dbip_downloaded = False

    def __check_db_version(self):
        """
        检测现存的db与当前年月是否对应
        无论如何最后都会在db文件夹存在一个文件
        :return:
        """
        # 默认需要去下载数据库
        need_download = True
        exist_csvname = None
        # 下载数据库的状态
        download_status = False

        year = self.date_now.year
        month = self.date_now.month
        file_list = [i for i in self.csvpath.iterdir()]
        file_count = len(file_list)
        if file_count > 0:
            # 全部删除了重新下载
            for file in file_list:
                exist_csvname: str = file.name
                name_list = exist_csvname[:exist_csvname.index('.')].split('-')
                db_year = int(name_list[0])
                db_month = int(name_list[1])
                if db_year == year and db_month == month:
                    # 符合要求当月的都能使用
                    need_download = False
                    break
        # 如果需要去下载新的数据库，那么就去下载
        if need_download:
            download_status = self.__download_db()
        # 检测下载状态，下载成功直接返回，如果没有下载成功那么就使用原有的db，原有的db也没有那么就报错
        if download_status:
            return True
        else:
            if exist_csvname is not None:
                oldcsvname = self.csvpath / exist_csvname
                oldcsvname.rename(self.csvname)
                return True
            else:
                self._logger.error(
                    'There is a problem with the network connection, no available csvmmdb can be use'
                )
                return False

    def __download_db(self):
        """
        在dbip网站下载mmdb
        购买了dbip库后直接使用秘钥去拿每月需要下载的dbip和csv库
        dbip_upgrade_url = 'https://db-ip.com/account/7fcd7421494b209426e44b8729aa1606c973e49a/db/ip-to-location-isp/'
        :return:
        """
        self._logger.info("Start init download csv sqlite")
        res = False
        gzname = self.tmppath / f'{self.date}.csv.gz'
        dbname = self.csvname
        try:
            dbip_upgrade_url = 'https://db-ip.com/account/7fcd7421494b209426e44b8729aa1606c973e49a/db/ip-to-location-isp/'
            response = requests.get(dbip_upgrade_url, timeout=(5, 5))
            d_res = json.loads(response.text)
            url = d_res.get('csv', {}).get('url')
            # 下载到tmp文件夹
            # url = f'https://download.db-ip.com/free/dbip-city-lite-{self.date}.csv.gz'

            f = PartDFile(url,
                          savedir=self.tmppath.absolute().as_posix(),
                          filename=f'{self.date}.csv.gz',
                          conncount=10)
            f.download_async(
                lambda a: self._logger.info("Csv db download completed"))

            while not f.download_complete:
                try:
                    self._logger.info(
                        f'Downloading dbipcsv: {f.download_total_size_realtime//(1024*1024)} Mb/ {f._totalsize//(1024*1024)} Mb    avg: {f.speed_average_str}'
                    )
                    time.sleep(2)
                except Exception as ex:
                    self._logger.error(f"Wait for downloading err: {ex.args}")

            # count = 0
            # with requests.get(url, stream=True, timeout=(5, 5)) as r:
            #     r.raise_for_status()
            #     total_length = math.ceil(
            #         int(r.headers.get('content-length')) / (1024 * 1024))
            #     with gzname.open('wb') as f:
            #         # with progressbar.ProgressBar(max_value=total_length, widgets=widgets) as bar:
            #         for chunk in r.iter_content(chunk_size=1024 * 1024):
            #             count += 1
            #             # bar.update(count)
            #             self._logger.info(
            #                 f'Downloading dbipcsv: {count} Mb/ {total_length} Mb'
            #             )
            #             if chunk:  # filter out keep-alive new chunks
            #                 f.write(chunk)
            self._logger.info('Please waite unzip csv.gz')
            # 解压到db文件夹
            with gzip.open(gzname.as_posix(), 'rb') as f_in:
                with dbname.open('wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
            res = True
            self._logger.info('unzip csv.gz success')
        except:
            self._logger.info(
                f"Download dbip error, please delete the tmp download and try again\nerr:{traceback.format_exc()}"
            )
            res = False
            # 删除dbname
            if dbname.exists():
                dbname.unlink()
        finally:
            # 删除tmppath里面的file
            if gzname.exists():
                gzname.unlink()
        return res

    def __store_csv_to_sqlite(self, sqlite_name, csv_name):
        """
        保存csv的数据到sqlite
        """
        res = False
        try:
            # 只有初始化的时候需要使用
            conn = sqlite3.connect(sqlite_name)
            c = conn.cursor()
            c.execute('''CREATE TABLE dbip
                   (ID INTEGER PRIMARY KEY autoincrement    NOT NULL,
                   ipstart        CHAR(50)   NOT NULL,
                   ipend          CHAR(50)   NOT NULL,
                   continent      CHAR(50),
                   country        CHAR(50),
                   province       CHAR(50),
                   city           CHAR(50),
                   geoid          CHAR(50));''')
            conn.commit()
            # 解决csv太大的问题4个G
            readstatus = True
            for chunk in pandas.read_csv(csv_name,
                                         low_memory=False,
                                         chunksize=40000):
                tmp_insert = []
                for i in chunk.values:
                    ipstart = i[0]
                    # ipv6暂时解析不了，后面就直接不解了
                    if ':' in ipstart:
                        readstatus = False
                        break
                    ipend = i[1]
                    continent = i[2]
                    country = i[3]
                    state = i[4]
                    city = i[5]
                    geoid = i[10]
                    tmp_insert.append((ipstart, ipend, continent, country,
                                       state, city, geoid))
                # 最后完成后判断下还有没有没插入的
                if len(tmp_insert) > 0:
                    c.executemany(
                        'INSERT INTO dbip(ipstart,ipend,continent,country,province,city,geoid) VALUES(?,?,?,?,?,?,?);',
                        tmp_insert)
                    conn.commit()
                    self._logger.info(
                        f"Store {len(tmp_insert)} lines into sqlite")
                if not readstatus:
                    break
            conn.close()
            res = True
            self._logger.info("Store csv data to sqlite success.")
        except Exception as error:
            self._logger.info(f"Store csv data to sqlite error, err:{error}")
        return res

    def __init__sqlite_db(self):
        """
        初始化的时候也检查下sqlite_db在不在
        """
        year = self.date_now.year
        month = self.date_now.month
        file_list = [i for i in self.sqlite_path.iterdir()]
        file_count = len(file_list)
        if file_count == 0:
            return self.__store_csv_to_sqlite(self.sqlite_name.as_posix(),
                                              self.csvname.as_posix())
        elif file_count > 1:
            # 全部删除了重新下载
            for file in file_list:
                file.unlink()
            return self.__store_csv_to_sqlite(self.sqlite_name.as_posix(),
                                              self.csvname.as_posix())
        # 现在就只剩下等于1的情况了
        db: Path = file_list[0]
        dbname: str = db.name
        name_list = dbname[:dbname.index('.')].split('-')
        db_year = int(name_list[0])
        db_month = int(name_list[1])
        if db_year == year and db_month == month:
            # 符合要求当月的都能使用
            return True
        else:
            # 已经是新的一月了，那么就删除当月的去下载下月的
            db.unlink()
            return self.__store_csv_to_sqlite(self.sqlite_name.as_posix(),
                                              self.csvname.as_posix())

    def _judge_provice(self, province):
        """
        判断有些一级行政区是否有国家二字码
        """
        res = None
        for el in country_code:
            name = el[0]
            code = el[1]
            if province == name or province in code:
                res = code
                break
        return res

    def find_geo_ip_ranges(self,
                           country_code,
                           province=None,
                           city=None,
                           geoid=None):
        """
        country_code:国家二字码不能为空
        province:需要判断一下有些省有二字码，需要在国家码里面才能查询到数据
        city:city名字
        geoid:geoname里面的唯一城市id
        """
        res = None
        conn = None
        # 最后返回这个对象
        seres = SeRes(conn, res)

        self.__manage_used_sqlite()

        if not DBIPMMDB._is_dbip_downloaded:
            self._logger.error(
                "Sqlite database is not downloaded, check the network")
            return seres

        sql = '''
        select ipstart, ipend from dbip where 
        '''
        rsql = []
        pars = []
        # 这里目前只有两种情况，只有1、只有country;2、有country和geoid
        if geoid is not None:
            rsql.append('geoid=?')
            pars.append(geoid)
        elif geoid is None and country_code is not None:
            rsql.append('country=?')
            pars.append(country_code)
        else:
            self._logger.error(f"country code and geoid cannot both be None")
            return seres
        # 这几句代码不要删除，可能以后数据库不续费了还需要这里面的方式by judy 2020/04/23
        # if province is not None:
        #     j_p_res = self._judge_provice(province)
        #     if j_p_res is not None:
        #         if country_code is not None:
        #             rsql.pop()
        #             pars.pop()
        #             rsql.append('country=?')
        #             pars.append(j_p_res)
        #     else:
        #         rsql.append('province=?')
        #         pars.append(province)
        # if city is not None:
        #     rsql.append('city=?')
        #     pars.append(city)
        sql += ' and '.join(rsql)

        try:
            conn = sqlite3.connect(self.sqlite_name.as_posix())
            c = conn.cursor()
            res = c.execute(sql, pars)  # 这样子返回的是迭代
            # res = c.fetchall()
        except Exception as err:
            self._logger.error(f"Fetch sqlite error\nsql:{sql}\nerror:{err}")
        # sqlite使用的是空间换时间策略，当与sqlite建立连接后会在内存中保存一份连接，如果只是查询的话可以一直保留这份连接
        finally:
            seres.conn = conn
            seres.res = res
        return seres

    def do_async_download_csv(self):
        import time
        # 经测试，在docker容器内报错时区不符，随便指定一个时区就可以解决
        # 此处统一指定为上海
        schedule = BackgroundScheduler(timezone="Asia/Shanghai")
        schedule.add_job(self.__async_download_csv,
                         'cron',
                         month="*",
                         day="1",
                         hour='3',
                         id='async_download_csv')
        schedule.start()
        while True:
            time.sleep(5)

    def __async_download_csv(self):
        """
        多线程检测是否下载了dbip，这样比以前下载的时候去下载dbip要快一点
        :return:
        """
        if DBIPMMDB._is_dbip_downloaded:
            return
        # 下载数据库的状态
        res = False
        try:
            with DBIPMMDB.__init_ip_locker:
                if DBIPMMDB._is_dbip_downloaded:
                    return
                # 这里包括检查版本和下载csv文件
                self.__delete_old_dbs()
                csvres = self.__check_db_update()
                # 下载失败就不去init sqlite了初始化也没用
                if not csvres:
                    return res
                # 下载完成csv文件后，初始化下sqlite数据库
                sqliteres = self.__check_sqlite_update()
                if csvres and sqliteres:
                    res = True
        except:
            self._logger.error(
                f"Init download dbip error, err:{traceback.format_exc()}")
        finally:
            if res:
                # 将下载完成的状态给上
                DBIPMMDB._is_dbip_downloaded = True
                DBIPMMDB._csv_date = self.date
            else:
                # 将下载完成的状态给上
                DBIPMMDB._is_dbip_downloaded = False

    def __delete_old_dbs(self):
        """
        扫描csv和dbipsqlite文件夹，删除老版本数据
        """
        month = self.date_now.month
        year = self.date_now.year

        file_list = [i for i in self.csvpath.iterdir()]
        if len(file_list) == 0:
            return
        for file in file_list:
            name_list = file.name.split(".")[0].split("-")
            name_month = int(name_list[1])
            if name_month < month:
                file.unlink()

        dbip_sqlite_file_list = [i for i in self.sqlite_path.iterdir()]
        if len(dbip_sqlite_file_list) == 0:
            return
        for file in dbip_sqlite_file_list:
            name_list = file.name.split(".")[0].split("-")
            name_year = int(name_list[0])
            name_month = int(name_list[1])
            if name_year == year:
                if name_month + 1 < month:
                    file.unlink()
            else:
                if name_month != 12:
                    file.unlink()

    def __check_db_update(self):
        date = self.date_now.strftime('%Y-%m')
        file_list = [
            i for i in self.csvpath.iterdir() if i.name.split(".")[0] == date
        ]
        file_count = len(file_list)
        if file_count == 0:
            return self.__download_db()
        else:
            return False

    def __check_sqlite_update(self):
        date = self.date_now.strftime('%Y-%m')
        file_list = [
            i for i in self.sqlite_path.iterdir()
            if i.name.split(".")[0] == date
        ]
        file_count = len(file_list)
        if file_count == 0:
            return self.__store_csv_to_sqlite(self.sqlite_name.as_posix(),
                                              self.csvname.as_posix())
        else:
            return False

    def __manage_used_sqlite(self):
        data = self.date_now.strftime('%Y-%m')
        file_list = [
            i for i in self.sqlite_path.iterdir()
            if i.name.split(".")[0] == data
        ]
        file_count = len(file_list)
        if file_count == 0:
            year = self.date_now.year
            month = self.date_now.month - 1
            if month < 10:
                date = f'{year}-0{month}'
            else:
                date = f'{year}-{month}'
            self.sqlite_name = self.sqlite_path / f'{date}.mmdb'
        else:
            DBIPMMDB._is_dbip_downloaded = True


if __name__ == '__main__':
    # test db download
    db_ip_mmdb = DBIPMMDB()

    # test get info
    info = db_ip_mmdb.find_geo_ip_ranges(country_code="IN")
    for i in info.res:
        print(i)
