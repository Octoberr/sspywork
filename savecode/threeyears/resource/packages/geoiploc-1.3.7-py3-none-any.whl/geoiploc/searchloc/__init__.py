from .searchlocmanager import SearchLocManager
