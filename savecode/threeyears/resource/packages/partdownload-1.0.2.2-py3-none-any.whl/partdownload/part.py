"""part"""

# -*- coding:utf-8 -*-


class Part:
    """part"""
    def __init__(self, startb: int, length: int, currlen: int = 0):
        if not isinstance(startb, int) or startb < 0:
            raise Exception("Invalid startb for part")
        if not isinstance(length, int):
            raise Exception("Invalid length for part")
        if not isinstance(currlen, int) or currlen < 0:
            raise Exception("Invalid currlen for part")

        self._startb: int = startb  # 当前Part起始byte位置，包含start
        self._length: int = length  # 当前Part结束byte位置，包含end
        self._currlen: int = currlen  # 当前Part已下载的基于startb的byte长度

    def set_currlen(self, currlen: int):
        if not isinstance(currlen, int) or currlen < 0 or currlen > self._length:
            raise Exception("Invalid currlen for Part")
        self._currlen = currlen
