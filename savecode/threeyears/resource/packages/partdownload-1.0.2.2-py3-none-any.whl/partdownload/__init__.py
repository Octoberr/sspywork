"""partdownload
Useage:

from partdownload import PartDFile

p = PartDFile(args)
# p.download_async(callback) or
p.download()

"""

# -*- coding:utf-8 -*-

from .partdfile import PartDFile