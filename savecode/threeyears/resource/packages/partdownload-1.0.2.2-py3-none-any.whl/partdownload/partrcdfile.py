"""represents a part-download record file"""

# -*- coding:utf-8 -*-

import io
import json
import os

from commonbaby.helpers import helper_time

from .part import Part


class PartDRcdFile:
    """represents a part-download record file"""

    # @property
    # def is_correct_rcd(self) -> bool:
    #     """用于标记当前读到的rcdfile是否与传入的url匹配"""
    #     return self._is_correct_rcd

    @property
    def parts(self) -> dict:
        return self.__parts

    @property
    def elapsed(self) -> int:
        """当前记录的总下载耗时时长，单位秒"""
        return self._elapsed

    def __init__(
        self,
        rcdfipath: str,
        url: str,
        headers: str,
        savedir: str,
        savefilename: str,
        realfilename: str,
        totalsize: int,
        conncount: int,
        partsize: float,
        cachesize: float,
        buffersize: float,
        createtime: int = None,
        elapsed: int = None,
    ):
        if not isinstance(rcdfipath, str) or rcdfipath == "":
            raise Exception("Invalid rcdfipath")
        self._rcdfipath: str = rcdfipath

        if not isinstance(url, str) or url == "":
            raise Exception("Invalid source url")
        self._url: str = url

        self._headers: str = None
        if isinstance(headers, str):
            self._headers = headers

        self._savedir: str = os.path.abspath("./")
        if isinstance(savedir, str) and savedir != "":
            self._savedir = os.path.abspath(savedir)

        if not isinstance(savefilename, str) or savefilename == "":
            raise Exception("Invalid savefilename")
        self._savefilename: str = savefilename

        if not isinstance(realfilename, str) or realfilename == "":
            raise Exception("Invalid realfilename")
        self._realfilename: str = realfilename

        if not isinstance(totalsize, int) or totalsize <= 0:
            raise Exception("Invalid totalsize")
        self._totalsize: int = totalsize

        if not isinstance(conncount, int) or conncount < 1:
            raise Exception("Invalid conncount")
        self._conncount: int = conncount

        if not type(partsize) in [int, float] or partsize < 1:
            raise Exception("Invalid partsize")
        self._partsize: float = partsize

        if not type(cachesize) in [int, float] or cachesize < 1:
            raise Exception("Invalid cachesize")
        self._cachesize: float = cachesize

        if not type(buffersize) in [int, float] or buffersize < 1:
            raise Exception("Invalid buffersize")
        self._buffersize: float = buffersize

        # 当前文件第一次创建的时间
        self._createtime: int = helper_time.ts_since_1970_tz()
        if isinstance(createtime, int) and not createtime < 1:
            self._createtime = createtime

        # 总共下载的耗时时长，单位秒
        self._elapsed: int = 0
        if type(elapsed) in [int, float] and elapsed > 0:
            self._elapsed = elapsed

        # parts <startb, Part obj>
        self.__parts: dict = {}

        # others
        self._rcdfistream: io.FileIO = None

    @classmethod
    def from_rcdfile(self, rcdfipath: str):
        """从已有的rcdfile初始化PartDRcdFile，失败返回None"""
        res: PartDRcdFile = None
        try:
            if not isinstance(rcdfipath, str) or not os.path.isfile(rcdfipath):
                return res

            jstr: str = None
            with open(rcdfipath, mode='r', encoding='utf-8') as fs:
                jstr = fs.read()

            jdict = json.loads(jstr)

            res: PartDRcdFile = PartDRcdFile(
                rcdfipath=rcdfipath,
                url=jdict["url"],
                headers=jdict["headers"],
                savedir=jdict["savedir"],
                savefilename=jdict["savefilename"],
                realfilename=jdict["realfilename"],
                totalsize=jdict["totalsize"],
                conncount=jdict["conncount"],
                partsize=jdict["partsize"],
                cachesize=jdict["cachesize"],
                buffersize=jdict["buffersize"],
                createtime=jdict["createtime"],
                elapsed=jdict["elapsed"],
            )

            if jdict.__contains__("parts"):
                for part in jdict["parts"]:
                    res.append_part(
                        Part(part["start"], part["length"], part["currlen"]))
            else:
                res._calc_parts()

        except Exception:
            raise
        return res

    def append_part(self, part: Part):
        """所有part不能有任何重复区间，且必须连续"""
        # 暂时不检查重复和连续性
        # 待完善
        self.__parts[part._startb] = part

    def _calc_parts(self):
        """重新计算所有parts"""
        if self._partsize >= self._totalsize:
            self.__parts[0] = Part(0, self._totalsize, 0)
        else:
            start: int = 0
            length: int = self._partsize
            while start + length < self._totalsize:
                if start == 0:
                    self.__parts[start] = Part(start, length, 0)

                start += self._partsize

                if start + self._partsize > self._totalsize:
                    length = self._totalsize - start

                self.__parts[start] = Part(start, length, 0)

    def get_rcd_current_size(self) -> int:
        """获取当前记录的已下载的文件大小"""
        if len(self.__parts) < 1:
            return 0

        res: int = 0
        for p in self.__parts.values():
            p: Part = p
            res += p._currlen

        return res

    def reset_parts(self):
        """清空parts记录"""
        self.__parts.clear()
        self._calc_parts()

    def reset_elapsed(self):
        self._elapsed = 0

    def get_parts(self) -> iter:
        """返回当前记录的所有parts"""
        if len(self.__parts) < 1:
            self._calc_parts()
        for p in self.__parts.values():
            yield p

    def update_part(self, part: Part):
        if self.__parts.__contains__(part._startb):
            self.__parts[part._startb] = part
        else:
            raise Exception("Unknown part")

    def update_elapsed(self, elapsed: [int, float]):
        if not type(elapsed) in [int, float] or elapsed < 0:
            raise Exception("Invalid elapsed seconds")
        self._elapsed = elapsed

    def save(self):
        """将当前rcd状态保存到文件。"""
        try:
            # 只有单线程操作，不需要上锁
            jdict: str = self._dumps()
            if jdict is None:
                raise Exception("Dumps rcd jdict failed")

            if self._rcdfistream is None or self._rcdfistream.closed:
                self._rcdfistream = open(self._rcdfipath,
                                         mode='w',
                                         encoding='utf-8')
            if not self._rcdfistream.writable():
                self._rcdfistream.close()
                self._rcdfistream = open(self._rcdfipath,
                                         mode='w',
                                         encoding='utf-8')

            self._rcdfistream.seek(0)
            self._rcdfistream.truncate(0)

            self._rcdfistream.write(jdict)
            self._rcdfistream.flush()

        except Exception:
            raise

    def _dumps(self) -> str:
        """将当前rcd状态转为json"""
        res: str = None
        try:
            jdict = {}
            jdict["url"] = self._url
            jdict["headers"] = self._headers
            jdict["savedir"] = self._savedir
            jdict["savefilename"] = self._savefilename
            jdict["realfilename"] = self._realfilename
            jdict["totalsize"] = self._totalsize
            jdict["conncount"] = self._conncount
            jdict["partsize"] = self._partsize
            jdict["cachesize"] = self._cachesize
            jdict["buffersize"] = self._buffersize
            jdict["createtime"] = self._createtime
            jdict["elapsed"] = self._elapsed

            if len(self.__parts) > 0:
                jdict["parts"] = []
                for p in self.__parts.values():
                    p: Part = p
                    jdict["parts"].append({
                        "start": p._startb,
                        "length": p._length,
                        "currlen": p._currlen
                    })

            res = json.dumps(jdict)

        except Exception:
            raise
        return res

    def dispose(self):
        """dispose file handles"""
        if not self._rcdfistream is None and not self._rcdfistream.closed:
            self._rcdfistream.flush()
            self._rcdfistream.close()
            self._rcdfistream = None

    def delete(self):
        """delete the rcd file"""
        self.dispose()
        if os.path.isfile(self._rcdfipath):
            os.remove(self._rcdfipath)

    def __del__(self):
        self.dispose()