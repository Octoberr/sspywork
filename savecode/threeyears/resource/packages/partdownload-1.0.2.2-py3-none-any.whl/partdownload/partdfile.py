"""represents a part-download file"""

# -*- coding:utf-8 -*-

import io
import os
import threading
from urllib import parse

import time
import gevent
import queue
from commonbaby.helpers import helper_time
from commonbaby.httpaccess import HttpAccess
from gevent import queue

from .part import Part
from .partdsavefile import PartDSaveFile
from .partrcdfile import PartDRcdFile

# Range: bytes=2001-4932


class PartDFile:
    """表示一个可分段下载的文件。\n
    :url:原始下载链接\n
    :headers:下载文件时要使用的http headers，每个header之间以换行分割，若有cookie需要带上\n
    :savedir:最终要保存到的目录\n
    :filename:最终要保存的文件名\n
    :conncount:最大并发连接数\n
    :partsize:每个下载分片的大小，单位byte，默认10MB，每个片分配一个链接去下载，建议根据带宽情况设置，会影响断开和新建连接的频率\n
    :cachesize:数据在内存缓存大小，单位byte，默认1MB，从网络流读取缓存大小的bytes后，才写入一次磁盘，会影响内存占用率和写磁盘的频率\n
    :buffersize:数据从网络流中读取的buffer大小，默认1MB，每收到buffer大小的bytes，才写入一次内存，会影响内存占用率\n
    """
    @property
    def part_unfinished_count(self) -> int:
        """尚未下载的part数量"""
        return self._queue.qsize()

    @property
    def part_total_count(self) -> int:
        """分片的总数量"""
        return len(self._rcdfile.parts)

    @property
    def conn_count_total(self) -> int:
        """返回连接数限制"""
        return self._rcdfile._conncount

    @property
    def conn_count_current(self) -> int:
        """返回当前已建立的连接数"""
        return self._curr_conn_cnt

    @property
    def rcd_current_size(self) -> int:
        """返回当前记录文件中记录的，已下载的数据量大小，单位byte"""
        return self._rcdfile.get_rcd_current_size()

    @property
    def download_total_size_realtime(self) -> int:
        """返回当前实时的已下载的总数据量大小，单位byte"""
        return self.__downloaded_total_size_realtime

    @property
    def create_time(self) -> int:
        """返回当前文件第一次被创建时的时间戳"""
        return self._rcdfile._createtime

    @property
    def elapsed_sec_realtime(self) -> int:
        """获取实时的已下载的时间长度，单位秒"""
        self._update_elapsed()
        return self.__elapsed_realtime

    @property
    def speed_average_str(self) -> str:
        """返回平均下载速率"""
        if not self.download_complete:
            total_size_in_Mbyte = self.download_total_size_realtime / 1048576
            if self.elapsed_sec_realtime == 0:
                self.__speed_average = total_size_in_Mbyte
            else:
                self.__speed_average = round(
                    total_size_in_Mbyte / self.elapsed_sec_realtime, 2)
        return "{}Mb/s".format(self.__speed_average)

    @property
    def speed_realtime_str(self) -> str:
        """返回字符串形式的当前实时下载速率"""
        size_per_sec = 0
        if not self._paused:
            delta_size = self.__downloaded_total_size_realtime - self.__downloaded_total_size_realtime_last
            delta_time = self.__downloaded_total_size_realtime_time - self.__downloaded_total_size_realtime_last_time
            if delta_time != 0:
                pow_time = 1 / delta_time
                size_per_sec = round((delta_size / 1048576) * pow_time, 2)
        return "{}Mb/s".format(size_per_sec)

    @property
    def download_complete(self) -> bool:
        """返回当前文件是否已经完成下载"""
        return self.__download_complete

    def __init__(
        self,
        url: str,
        headers: str = None,
        savedir: str = './',
        filename: str = None,
        totalsize: float = -1,
        conncount: int = 2,
        partsize: float = 104857600,
        cachesize: float = 10485760,
        buffersize: float = 1048576,
        proxies: dict = None,
        use_gevent: bool = False,
    ):
        if not isinstance(url, str) or url == "":
            raise Exception("Invalid source url")
        self._url: str = url

        self._use_gevent: bool = False
        if isinstance(use_gevent, bool):
            self._use_gevent = use_gevent

        self._headers: str = None
        if isinstance(headers, str):
            self._headers = headers

        self._savedir: str = os.path.abspath("./")
        if isinstance(savedir, str) and savedir != "":
            self._savedir = os.path.abspath(savedir)

        # 实际文件名，从url中提取
        self._realfilename: str = self.get_filename_from_url(self._url)
        self._savefilename: str = filename
        if not isinstance(self._savefilename, str) or self._savefilename == "":
            self._savefilename = self._realfilename

        self._proxies: dict = proxies

        self._ha: HttpAccess = HttpAccess()

        # get total size of the file
        self._totalsize: int = totalsize
        if self._totalsize <= 0:
            self._totalsize = self._request_file_size()

        # create/find the rcd file
        self._rcdfile: PartDRcdFile = self._find_rcdfile()
        if self._rcdfile is None:
            self._rcdfile = PartDRcdFile(
                rcdfipath=os.path.join(self._savedir,
                                       self._savefilename + ".pdrcd"),
                url=self._url,
                headers=self._headers,
                savedir=self._savedir,
                savefilename=self._savefilename,
                realfilename=self._realfilename,
                totalsize=self._totalsize,
                conncount=conncount,
                partsize=partsize,
                cachesize=cachesize,
                buffersize=buffersize,
            )

        # create/find the save file stream
        self._savefi: PartDSaveFile = PartDSaveFile(self._savedir,
                                                    self._savefilename)
        rcdsize = self._rcdfile.get_rcd_current_size()
        if not self._savefi.check_savefile_correction(
                rcdsize) and rcdsize <= 0:
            # 大小不对时不需要完全重置，可以接着下载即可
            self._rcdfile.reset_parts()
            self._rcdfile.reset_elapsed()
            self._savefi.reset_file()

        # flow control fields
        self._started: bool = False
        self.__started_locker = threading.RLock()

        self._paused: bool = False
        self.__paused_locker = threading.RLock()

        self._curr_conn_cnt = 0
        self._queue = queue.Queue()
        if self._use_gevent:
            self._queue = gevent.queue.Queue()

        # self.__write_locker = gevent.lock.Semaphore(1)

        self._events: list = []

        # info fields
        # self.__last_sec_size: float = 0  # 上一秒的实时下载大小，用于计算实时下载速率
        self.__downloaded_total_size_realtime_last: int = 0
        self.__downloaded_total_size_realtime_last_time: float = 0
        # 实时下载总数据量大小，单位byte
        self.__downloaded_total_size_realtime: int = self._rcdfile.get_rcd_current_size(
        )
        self.__downloaded_total_size_realtime_time: float = 0

        self.__speed_realtime: float = 0  #实时下载速率，单位byte/s
        self.__speed_average: float = 0  # 平均下载速率，单位byte/s

        self.__elapsed_realtime: float = self._rcdfile.elapsed
        self.__last_running_timestamp: float = None

        self.__download_complete: bool = False

######
# init

    def get_filename_from_url(self, url: str) -> str:
        """return filename from url, return None if failed"""
        res: str = None
        try:
            p = parse.urlparse(url)
            tmp = p.path.split('/')
            res = tmp[-1]
        except Exception:
            res = None
        return res

    def _request_file_size(self) -> int:
        """请求文件基本信息并记录"""
        res: int = -1
        resp = None
        try:

            resp = self._ha.get_response(self._url,
                                         headers=self._headers,
                                         stream=True,
                                         verify=True)
            res = resp.headers.get("Content-Length")
            if isinstance(res, str) and not res == "":
                res = int(res)
            # res = resp.headers["Content-Length"]

        except Exception:
            res = -1
            raise
        finally:
            if not resp is None:
                resp.close()
        return res

    def _find_rcdfile(self) -> PartDRcdFile:
        """找url一样的rcdfile，返回rcdfile文件路径，无则返回None"""
        rcdfi: PartDRcdFile = None
        try:
            # 先找文件名一样的
            fi: str = os.path.join(self._savedir,
                                   self._savefilename + ".pdrcd")
            if os.path.isfile(fi):
                rcdfi: PartDRcdFile = PartDRcdFile.from_rcdfile(fi)
                if not isinstance(rcdfi, PartDRcdFile):
                    # 失败说明记录文件格式受损，直接删掉
                    os.remove(fi)
                elif rcdfi._url == self._url and rcdfi._totalsize == self._totalsize:
                    return rcdfi

            # 再找其他的
            if not os.path.isdir(self._savedir):
                os.makedirs(self._savedir)
            for n in os.listdir(self._savedir):
                if not n.endswith(".pdrcd"):
                    continue
                fi = os.path.join(self._savedir, n)
                if not os.path.isfile(fi):
                    continue
                rcdfi: PartDRcdFile = PartDRcdFile.from_rcdfile(fi)
                if not isinstance(rcdfi, PartDRcdFile):
                    # 失败说明记录文件格式受损，直接删掉
                    os.remove(fi)
                elif rcdfi._url == self._url and rcdfi._totalsize == self._totalsize:
                    return rcdfi

        except Exception:
            raise
        return rcdfi

    def _update_elapsed(self):
        if not self.__download_complete and self._started and not self._paused:
            curr = helper_time.ts_since_1970_tz()
            self.__elapsed_realtime = self.__elapsed_realtime + (
                curr - self.__last_running_timestamp)
            self.__last_running_timestamp = curr
            self._rcdfile.update_elapsed(self.__elapsed_realtime)


######
# download

    def download(self, timeout=None, raise_error=True, count=None):
        """start download.\n

        Wait for the ``greenlets`` to finish.\n
        :param greenlets: A sequence (supporting :func:`len`) of greenlets to wait for.\n
        :keyword float timeout: If given, the maximum number of seconds to wait.\n
        :count:If ``count`` is ``None`` (the default), wait for all ``objects``\n
            to become ready.If ``count`` is a number, wait for (up to) ``count`` objects to become
            ready. (For example, if count is ``1`` then the function exits
            when any object in the list is ready).\n
        :return: A sequence of the greenlets that finished before the timeout (if any)
        expired."""
        res: bool = True
        try:

            self._download()

            if self._use_gevent:
                gevent.joinall(self._events,
                               timeout=timeout,
                               raise_error=raise_error,
                               count=count)
            else:
                for e in self._events:
                    # e: threading.Thread = e
                    e.join(timeout=timeout)

        except Exception:
            raise
        finally:
            if self._paused:
                self._update_elapsed()
                self._rcdfile.save()
            # ok = True
            # while True:
            #     for e in self._events:
            #         if not e.successful():
            #             ok = False
            #             break
            #     if not ok:
            #         ok = True
            #         gevent.sleep(0.001)
            #     else:
            #         break

            self.dispose()

            if self._rcdfile.get_rcd_current_size() >= self._totalsize:
                self.__download_complete = True

            if self.__download_complete:
                self._rcdfile.delete()

    def download_async(self,
                       callback: callable,
                       timeout=None,
                       raise_error=False,
                       count=None):
        """start download asynchrously.\n
        
        :callback: 一个回调函数，用于接收下载完成的信号：\n
            def on_download_ok(args):
                print('download complete')

        Wait for the ``greenlets`` to finish.
        :param greenlets: A sequence (supporting :func:`len`) of greenlets to wait for.
        :keyword float timeout: If given, the maximum number of seconds to wait.
        :return: A sequence of the greenlets that finished before the timeout (if any)
        expired."""
        try:

            self._download()

            if self._use_gevent:
                e = gevent.spawn(self._wait_for_gevents, callback)
            else:
                e = threading.Thread(target=self._wait_for_gevents,
                                     daemon=True,
                                     args=[
                                         callback,
                                     ])
                e.start()

        except Exception:
            raise

    def _wait_for_gevents(self,
                          callback: callable,
                          timeout=None,
                          raise_error=False,
                          count=None):
        try:
            try:
                
                if self._use_gevent:
                    res = gevent.joinall(self._events,
                                        timeout=timeout,
                                        raise_error=raise_error,
                                        count=count)
                else:
                    for e in self._events:
                        # e: threading.Thread = e
                        e.join(timeout=timeout)

            finally:
                if self._paused:
                    self._update_elapsed()
                    self._rcdfile.save()

                # ok = True
                # while True:
                #     for e in self._events:
                #         if not e.successful():
                #             ok = False
                #             break
                #     if not ok:
                #         ok = True
                #         gevent.sleep(0.001)
                #     else:
                #         break

                self.dispose()

                if self._rcdfile.get_rcd_current_size() >= self._totalsize:
                    self.__download_complete = True

                if self.__download_complete:
                    self._rcdfile.delete()

            if self.__download_complete and callable(callback):
                callback(self._savefi._savefipath)

        except Exception:
            raise

    def _download(self) -> list:
        """do download function synchrously"""
        try:
            if self._started:
                return
            with self.__started_locker:
                if self._started:
                    return
                self.__last_running_timestamp = helper_time.ts_since_1970_tz()
                self._started = True

            self._start_download()

        except Exception:
            raise

    def _start_download(self):
        """"""
        # start download
        for part in self._rcdfile.get_parts():
            # part:Part = part
            if part._currlen >= part._length:
                continue
            self._queue.put(part)

        # init rcd
        self._rcdfile.save()

        if self._use_gevent:
            e = gevent.spawn(self._start_partial_download)
        else:
            e = threading.Thread(target=self._start_partial_download,
                                 daemon=True)
            e.start()
        self._events.append(e)

    def _start_partial_download(self):
        try:
            while self._queue.qsize() > 0:

                if self._paused:
                    break

                part: Part = self._queue.get()

                if self._use_gevent:
                    event = gevent.spawn(self._download_a_part, part)
                else:
                    event = threading.Thread(target=self._download_a_part,
                                             daemon=True,
                                             args=[
                                                 part,
                                             ])
                    event.start()

                self._events.append(event)

                self._curr_conn_cnt += 1

                while self._curr_conn_cnt >= self._rcdfile._conncount:
                    if self._use_gevent:
                        gevent.sleep(0.1)
                    else:
                        time.sleep(0.1)
                    # print(q.qsize())

        except Exception:
            raise

    def pause(self):
        """pause the download.\n
        this will close all connections."""
        if self._paused:
            return
        with self.__paused_locker:
            if self._paused:
                return
            self._paused = True

    def resume(self):
        """resume the download"""
        if not self._paused:
            return
        with self.__paused_locker:
            if not self._paused:
                return
            self.__last_running_timestamp = helper_time.ts_since_1970_tz()
            self._paused = False
            self._start_download()

    def cancel(self):
        """stop download and remove all files"""
        pass

    def _download_a_part(self, part: Part):
        """download a part of the file"""
        try:
            if not isinstance(part, Part):
                raise Exception("Invalid part for downloading")

            # Range: bytes=2001-4932
            # 表示从2001到4932，包含第2001和4932个字节
            # 所以换算到length长度的话要-1才是最后一个字节的索引
            start = part._startb + part._currlen
            end = part._startb + part._length - 1  #

            headers = self._ha._parse_req_headers(self._headers)
            headers["Range"] = "bytes={}-{}".format(start, end)
            headersstr = ""
            for k, v in headers.items():
                headersstr += "{}: {}\n".format(k, v)

            respstm = None
            try:

                respstm = self._ha.get_response_stream(
                    self._url,
                    headers=headersstr,
                    proxies=self._proxies,
                )

                # 自行控制流读取
                cache: bytes = bytes()
                currstart = start
                while True:
                    try:
                        chunk = respstm.read(self._rcdfile._buffersize,
                                             self._rcdfile._buffersize)

                        chunklen = 0
                        if not chunk is None:
                            chunklen = len(chunk)

                        self.__downloaded_total_size_realtime_last = self.__downloaded_total_size_realtime
                        self.__downloaded_total_size_realtime_last_time = self.__downloaded_total_size_realtime_time
                        self.__downloaded_total_size_realtime += chunklen
                        self.__downloaded_total_size_realtime_time = helper_time.ts_since_1970_tz(
                        )

                        if chunk is None or chunklen <= 0:
                            if len(cache) > 0:
                                # with self.__write_locker:
                                self._savefi.write(cache, currstart)
                                part.set_currlen(part._currlen + len(cache))

                                cache = bytes()
                                self._rcdfile.update_part(part)
                                self._update_elapsed()
                                self._rcdfile.save()
                                currstart = part._startb + part._currlen
                            break

                        cache += chunk

                        if chunklen < self._rcdfile._buffersize or len(
                                cache) >= self._rcdfile._cachesize:
                            # with self.__write_locker:
                            self._savefi.write(cache, currstart)
                            part.set_currlen(part._currlen + len(cache))

                            cache = bytes()
                            self._rcdfile.update_part(part)
                            self._update_elapsed()
                            self._rcdfile.save()
                            currstart = part._startb + part._currlen

                        if self._paused:
                            break

                    except Exception as e:
                        raise e
            finally:
                if not respstm is None and not respstm.closed:
                    respstm.close()

        except Exception as ex:
            self._queue.put(part)
            raise
        finally:
            self._curr_conn_cnt -= 1

    def dispose(self):
        """dispose all connections and file handles"""
        self._rcdfile.save()
        self._rcdfile.dispose()
        self._savefi.dispose()
