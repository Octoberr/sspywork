"""partdsavefile"""

# -*- coding:utf-8 -*-

import io
import os

import gevent


class PartDSaveFile:
    """part"""
    def __init__(self, savedir: str, savefiname: str):
        if not isinstance(savedir, str):
            raise Exception("Invalid savedir")
        if not isinstance(savefiname, str):
            raise Exception("Invalid savefilename")

        self._savedir: str = savedir
        # if not os.path.isdir(self._savedir):
        #     os.makedirs(self._savedir)

        self._savefiname: str = savefiname

        self._savefipath: str = os.path.join(self._savedir, self._savefiname)

        self._savefistream: io.FileIO = None

    def check_savefile_correction(self, expectsize: int) -> bool:
        """check if the savefile size is correct"""
        res: bool = False
        try:
            if expectsize == 0:
                if not os.path.isfile(self._savefipath):
                    res = True
                else:
                    if os.path.getsize(self._savefipath) != 0:
                        os.remove(self._savefipath)
                    res = True
            else:
                if os.path.isfile(self._savefipath) and os.path.getsize(
                        self._savefipath) == expectsize:
                    res = True
        except Exception:
            raise
        return res

    def reset_file(self):
        """重置、删除已下载的数据"""
        if os.path.isfile(self._savefipath):
            if not self._savefistream is None:
                self._savefistream.close()
            os.remove(self._savefipath)

    def write(self, data: bytes, idx: int):
        """从流的idx位置开始，写入data"""
        if not os.path.isfile(self._savefipath):
            with open(self._savefipath, mode='wb') as fs:
                fs.truncate(0)
        if self._savefistream is None or self._savefistream.closed:
            self._savefistream = open(self._savefipath, mode='rb+')
        if not self._savefistream.writable():
            self._savefistream.flush()
            self._savefistream.close()
            self._savefistream = open(self._savefipath, mode='rb+')

        self._savefistream.seek(idx, 0)
        self._savefistream.write(data)
        self._savefistream.flush()

    def dispose(self):
        """dispose file handle"""
        if not self._savefistream is None and not self._savefistream.closed:
            self._savefistream.flush()
            self._savefistream.close()
            self._savefistream = None

    def __del__(self):
        self.dispose()
